data "terraform_remote_state" "vpc_state" {
  backend = "s3"

  config = {
    bucket   = var.backend_bucket
    key      = "${var.backend_path}/backend/vpc"
    region   = var.region
    role_arn   = var.role_arn
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"

  config = {
    bucket   = var.backend_bucket
    key      = "${var.backend_path}/backend/eks"
    region   = var.region
    role_arn   = var.role_arn
  }
}

data "terraform_remote_state" "kms" {
  backend = "s3"

  config = {
    bucket   = var.backend_bucket
    key      = "${var.backend_path}/backend/kms"
    region   = var.region
    role_arn   = var.role_arn
  }
}


resource "aws_iam_role" "node" {
  name = "eks-${var.cluster_name}-node-0"

  assume_role_policy = <<POLICY
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
POLICY
}

resource "aws_iam_policy" "ebs_decryption_policy" {
  name = "EBSDecryptionPolicy"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:DescribeKey"
        ],
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_policy" "node_ca" {
  name        = "eks-${var.cluster_name}-ca"
  path        = "/"
  description = "EKS Cluster Autoscaler policy"

  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": [
        "autoscaling:DescribeAutoScalingGroups",
        "autoscaling:DescribeAutoScalingInstances",
        "autoscaling:DescribeLaunchConfigurations",
        "autoscaling:DescribeTags",
        "autoscaling:SetDesiredCapacity",
        "autoscaling:TerminateInstanceInAutoScalingGroup",
        "ec2:DescribeLaunchTemplateVersions"
      ],
      "Effect": "Allow",
      "Resource": "*"
    }
  ]
}
EOF
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEBSCSIDriverPolicy-node" {
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEFSCsiDriverPolicy-node" {
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonEFSCSIDriverPolicy"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "node_AmazonEKSWorkerNodePolicy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "node_AmazonEKS_CNI_Policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "node_AmazonEC2ContainerRegistryReadOnly" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "CloudWatchAgentServerPolicy" {
  count      = var.cloudwatch_logs ? 1 : 0
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "node_ca" {
  policy_arn = aws_iam_policy.node_ca.arn
  role       = aws_iam_role.node.name
}

resource "aws_iam_role_policy_attachment" "attach_ebs_decryption_policy" {
  policy_arn = aws_iam_policy.ebs_decryption_policy.arn
  role       = aws_iam_role.node.name
}

resource "tls_private_key" "ssh_server_eks" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "aws_key_pair" "eks" {
  key_name   = var.eks_key_name
  public_key = var.public_key_file != null ? file(var.public_key_file) : tls_private_key.ssh_server_eks.public_key_openssh
}

resource "aws_security_group" "node_group_sg" {
  count       = length(var.node_groups_decimal)
  name        = "${var.cluster_name}-${var.node_groups_decimal[count.index].name}-sg"
  description = "Security group for EKS node group ${var.node_groups_decimal[count.index].name}"
  vpc_id      = data.terraform_remote_state.vpc_state.outputs.vpc_id

  # Dynamic ingress rules for each node group
  dynamic "ingress" {
    for_each = var.node_groups_decimal[count.index].ingress_rules
    content {
      from_port   = ingress.value.from_port
      to_port     = ingress.value.to_port
      protocol    = ingress.value.protocol
      cidr_blocks = ingress.value.cidr_blocks
    }
  }

  # Dynamic egress rules for each node group
  dynamic "egress" {
    for_each = var.node_groups_decimal[count.index].egress_rules
    content {
      from_port   = egress.value.from_port
      to_port     = egress.value.to_port
      protocol    = egress.value.protocol
      cidr_blocks = egress.value.cidr_blocks
    }
  }

  tags = {
    Name = "${var.cluster_name}-${var.node_groups_decimal[count.index].name}-sg"
  }
}


resource "aws_eks_node_group" "decimal" {
  count           = length(var.node_groups_decimal)
  cluster_name    = data.terraform_remote_state.eks.outputs.eks_cluster_id
  node_group_name = "${var.cluster_name}-${var.node_groups_decimal[count.index].name}"
  node_role_arn   = aws_iam_role.node.arn
  subnet_ids      = data.terraform_remote_state.vpc_state.outputs.private_subnet_ids
  instance_types = var.node_groups_decimal[count.index].instance_types
#  ami_type        = "CUSTOM"
  capacity_type   = var.node_groups_decimal[count.index].capacity_type 

  launch_template {
    id      = aws_launch_template.eks_decimal[0].id
    version = "$Latest"
  }

  labels = var.node_groups_decimal[count.index].labels

  taint {
    key    = var.node_groups_decimal[count.index].tolerations.key
    value  = var.node_groups_decimal[count.index].tolerations.value
    effect = var.node_groups_decimal[count.index].tolerations.effect
  }

  scaling_config {
    desired_size = var.node_groups_decimal[count.index].desired_size
    max_size     = var.node_groups_decimal[count.index].maximum_size
    min_size     = var.node_groups_decimal[count.index].minimum_size
  }

  tags = var.node_groups_decimal[count.index].ng_decimal_tags

  depends_on = [
    aws_iam_role_policy_attachment.node_AmazonEKSWorkerNodePolicy,
    aws_iam_role_policy_attachment.node_AmazonEKS_CNI_Policy,
    aws_iam_role_policy_attachment.node_AmazonEC2ContainerRegistryReadOnly,
  ]
}

resource "aws_eks_node_group" "decimal_no_tt" {
  count           = length(var.node_groups_decimal_tt)
  cluster_name    = data.terraform_remote_state.eks.outputs.eks_cluster_id
  node_group_name = "${var.cluster_name}-${var.node_groups_decimal_tt[count.index].name}"
  node_role_arn   = aws_iam_role.node.arn
  subnet_ids      = data.terraform_remote_state.vpc_state.outputs.private_subnet_ids
  instance_types = var.node_groups_decimal_tt[count.index].instance_types
#  ami_type        = "CUSTOM"
  capacity_type   = var.node_groups_decimal_tt[count.index].capacity_type 

  launch_template {
    id      = aws_launch_template.eks_decimal[0].id
    version = "$Latest"
  }

  labels = var.node_groups_decimal_tt[count.index].labels

  scaling_config {
    desired_size = var.node_groups_decimal_tt[count.index].desired_size
    max_size     = var.node_groups_decimal_tt[count.index].maximum_size
    min_size     = var.node_groups_decimal_tt[count.index].minimum_size
  }

  tags = var.node_groups_decimal_tt[count.index].ng_decimal_tags

  depends_on = [
    aws_iam_role_policy_attachment.node_AmazonEKSWorkerNodePolicy,
    aws_iam_role_policy_attachment.node_AmazonEKS_CNI_Policy,
    aws_iam_role_policy_attachment.node_AmazonEC2ContainerRegistryReadOnly,
  ]
}