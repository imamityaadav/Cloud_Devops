def call() {
    def s3BucketCreation = env.S3_BUCKET_CREATION.toBoolean()

    if (s3BucketCreation) {
        echo "Creating S3 bucket and backend folders"
        
        // Use the assume-role command to get temporary credentials
        def assumeRoleOutput = sh(script: """
            aws sts assume-role \
                --role-arn ${env.roleArn} \
                --role-session-name my-session \
                --output json
        """, returnStdout: true).trim()

        def roleCredentials = readJSON(text: assumeRoleOutput)
        def accessKeyId = roleCredentials.Credentials.AccessKeyId
        def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
        def sessionToken = roleCredentials.Credentials.SessionToken

        // Export the temporary credentials as environment variables
        withEnv(["AWS_ACCESS_KEY_ID=${accessKeyId}", "AWS_SECRET_ACCESS_KEY=${secretAccessKey}", "AWS_SESSION_TOKEN=${sessionToken}"]) {
            sh """#!/bin/bash
            # Check if the bucket exists
            if aws s3api head-bucket --bucket ${env.BUCKET_NAME} --region ${env.REGION} > /dev/null 2>&1; then
                echo "Bucket ${env.BUCKET_NAME} already exists. Continuing..."
                echo "Creating folders in the bucket..."
                aws s3api put-object --bucket ${env.BUCKET_NAME} --key ${env.MAIN_FOLDER}/backend/ --region ${env.REGION}
                aws s3api put-object --bucket ${env.BUCKET_NAME} --key ${env.MAIN_FOLDER}/keys/ --region ${env.REGION}
                echo "Folders created in bucket ${env.BUCKET_NAME} successfully."
            else
                echo "Creating bucket ${env.BUCKET_NAME}..."
                # Create the bucket with LocationConstraint for specific regions (excluding us-east-1)
                if [ "${env.REGION}" != "us-east-1" ]; then
                    aws s3api create-bucket --bucket ${env.BUCKET_NAME} --region ${env.REGION} --create-bucket-configuration LocationConstraint=${env.REGION}
                else
                    aws s3api create-bucket --bucket ${env.BUCKET_NAME} --region ${env.REGION}
                fi
                echo "Bucket ${env.BUCKET_NAME} created successfully."
                echo "Creating folders in the bucket..."
                aws s3api put-object --bucket ${env.BUCKET_NAME} --key ${env.MAIN_FOLDER}/backend/ --region ${env.REGION}
                aws s3api put-object --bucket ${env.BUCKET_NAME} --key ${env.MAIN_FOLDER}/keys/ --region ${env.REGION}
                echo "Folders created in bucket ${env.BUCKET_NAME} successfully."
            fi
            """
        }
    } else {
        echo "S3 bucket creation is not enabled; skipping S3 bucket creation."
    }
}
