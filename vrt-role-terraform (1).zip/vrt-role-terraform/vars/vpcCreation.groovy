def call() {
    dir('terraform/environments/dev/vpc') {
        // Initialize Terraform backend with specified configurations
        sh """
            echo no | terraform init \
            -backend-config='bucket=${env.BUCKET_NAME}' \
            -backend-config='key=${env.MAIN_FOLDER}/backend/vpc' \
            -backend-config='region=${env.REGION}' \
            -backend-config='role_arn=${env.roleArn}' \
            -reconfigure
        """

        // Create a Terraform plan and save it for review
        def tfPlanCmd = "terraform plan -out=vpc_tfplan --var-file=../../../variables/dev.tfvars"
        sh tfPlanCmd
        sh 'terraform show -no-color vpc_tfplan > vpc_tfplan.txt'

        def autoApprove = env.AUTO_APPROVE.toBoolean()

        // If autoApprove is false, prompt the user for manual approval
        if (!autoApprove) {
            def plan = readFile 'vpc_tfplan.txt'
            input message: "Do you want to apply the plan?",
                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
        }

        // Apply the Terraform plan and save the output to a log file
        sh "terraform apply -input=false vpc_tfplan > terraform_output.log"
    }
}