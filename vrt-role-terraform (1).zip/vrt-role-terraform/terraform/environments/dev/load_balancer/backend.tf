terraform {
  backend "s3" {
    bucket     = var.backend_bucket
    key        = "${var.backend_path}/backend/load_balancer"
    region     = var.region
    role_arn   = var.role_arn
  }
}
