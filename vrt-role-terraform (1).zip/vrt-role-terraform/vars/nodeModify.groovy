def call() {
    // Define the cluster name and AWS region
    def clusterName = env.CLUSTER_NAME
    def region = env.REGION
    def roleArn = env.roleArn

    // Step 1: Assume the Role and Get Temporary Credentials
    def assumeRoleOutput = sh(
        script: """
            aws sts assume-role \
                --role-arn ${roleArn} \
                --role-session-name my-session \
                --output json \
                --region ${region}
        """, 
        returnStdout: true
    ).trim()

    echo "Assume Role Output: ${assumeRoleOutput}"

    def roleCredentials = readJSON(text: assumeRoleOutput)
    def accessKeyId = roleCredentials.Credentials.AccessKeyId
    def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
    def sessionToken = roleCredentials.Credentials.SessionToken

    // Step 2: Execute AWS Commands with Temporary Credentials
    withEnv([
        "AWS_ACCESS_KEY_ID=${accessKeyId}",
        "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
        "AWS_SESSION_TOKEN=${sessionToken}",
        "AWS_REGION=${region}"
    ]) {
        // Split and trim the node group names passed in NODEGROUP_MODIFY
        def selectedNodeGroups = env.NODEGROUP_MODIFY.split(",").collect { it.trim() }

        // Iterate over each node group name
        selectedNodeGroups.each { nodeGroupName ->
            def nodeGroupFullName = "${clusterName}-${nodeGroupName}"
            echo "Updating Auto Scaling group: ${nodeGroupFullName}"

            def autoScalingGroupName

            try {
                // Retrieve the Auto Scaling Group name
                autoScalingGroupName = sh(
                    returnStdout: true,
                    script: """
                        aws eks describe-nodegroup \
                            --cluster-name ${clusterName} \
                            --nodegroup-name ${nodeGroupFullName} \
                            --query "nodegroup.resources.autoScalingGroups[*].name" \
                            --output text
                    """
                ).trim()

                echo "Retrieved Auto Scaling Group name for ${nodeGroupFullName}: ${autoScalingGroupName}"

                if (autoScalingGroupName && autoScalingGroupName != "None") {
                    echo "Auto Scaling Group name: ${autoScalingGroupName}"

                    // Update the Auto Scaling Group configuration
                    sh """
                        aws autoscaling update-auto-scaling-group \
                            --auto-scaling-group-name ${autoScalingGroupName} \
                            --min-size ${env.ASG_MIN} \
                            --max-size ${env.ASG_MAX} \
                            --desired-capacity ${env.ASG_DESIRED}
                    """
                    echo "Successfully updated Auto Scaling Group: ${autoScalingGroupName}"
                } else {
                    error "Failed to retrieve the Auto Scaling Group name for node group: ${nodeGroupFullName}."
                }
            } catch (Exception e) {
                error "Error processing node group '${nodeGroupFullName}': ${e.message}"
            }
        }
    }

    // Final message after the update
    echo "Successfully updated the specified Auto Scaling Groups."
}
