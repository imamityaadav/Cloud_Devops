data "terraform_remote_state" "vpc_state" {
  backend = "s3"

  config = {
    bucket     = var.backend_bucket
    key        = "${var.backend_path}/backend/vpc"
    region     = var.region
    role_arn   = var.role_arn
  }
}

resource "aws_lb" "vrt_load_balancer" {
  name                       = var.load_balancer_name
  internal                   = var.internal
  load_balancer_type         = var.load_balancer_type
  enable_deletion_protection = false
  security_groups            = [aws_security_group.tf-sg.id]
  subnets                    = data.terraform_remote_state.vpc_state.outputs.public_subnet_ids
  tags = var.lb_tags
}


resource "aws_lb_listener" "lis80" {
  load_balancer_arn = aws_lb.vrt_load_balancer.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg.arn

  }
}

resource "aws_lb_target_group" "tg" {
  name     = var.target-group-name
  port     = var.lb-port
  protocol = var.protocol
  vpc_id   = data.terraform_remote_state.vpc_state.outputs.vpc_id
  health_check {
    path                = "/healthz"  # Set your custom health check path
    protocol            = "HTTP"      # Health check protocol (usually HTTP or HTTPS)
    interval            = 30          # Optional: Interval in seconds between health checks
    timeout             = 5           # Optional: Time in seconds to wait for a health check response
    healthy_threshold   = 3           # Optional: Number of consecutive successful checks before considering the target healthy
    unhealthy_threshold = 2           # Optional: Number of consecutive failed checks before considering the target unhealthy
  }
}

resource "aws_security_group" "tf-sg" {
  vpc_id      = data.terraform_remote_state.vpc_state.outputs.vpc_id
  name        = var.lb_security_group
  description = var.lb_security_group

    ingress {
    description = "Allow HTTP traffic from internet"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
    
    ingress {
    description = "Allow HTTP traffic from internet"
    from_port   = 30023
    to_port     = 30023
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group_rule" "sg_rule_ig" {
  type              = "egress"
  from_port         = var.from_ports
  to_port           = var.to_ports
  protocol          = "tcp"
  cidr_blocks       = [var.security-group-cidr]
  security_group_id = aws_security_group.tf-sg.id
  description       = "security group rule for tf-sg"
}

# uncomment this when you have a existing autoscalng group 

#resource "aws_autoscaling_attachment" "test" {
#  autoscaling_group_name = var.autoscaling-group-name
#  lb_target_group_arn   = aws_lb_target_group.tg.arn
#}
