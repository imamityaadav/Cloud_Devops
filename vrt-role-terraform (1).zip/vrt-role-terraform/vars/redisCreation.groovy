def call() {
    dir('terraform/environments/dev/elasticache') {
                        sh "terraform init \
                            -backend-config='bucket=${env.BUCKET_NAME}' \
                            -backend-config='region=${env.REGION}' \
                            -backend-config='key=${env.MAIN_FOLDER}/backend/elasticache' \
                            -backend-config='role_arn=${env.roleArn}' \
                            -reconfigure"
                        def tfPlanCmd = "terraform plan -out=ec_tfplan --var-file=../../../variables/dev.tfvars"
                        sh tfPlanCmd
                        sh 'terraform show -no-color ec_tfplan > ec_tfplan.txt'
                        def autoApprove = env.AUTO_APPROVE.toBoolean()

                        // Check if autoApprove is false, then ask for manual approval
                        if (!autoApprove) {
                            def plan = readFile 'ec_tfplan.txt'
                            input message: "Do you want to apply the plan?",
                                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                        }
                        sh "terraform apply -input=false ec_tfplan > terraform_output.log"
            }
        }
    
