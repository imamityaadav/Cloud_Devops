terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.20.0"
    }
  }
}

provider "aws" {
  region = var.region

  # Use assume_role block to assume the role
  assume_role {
    role_arn = var.role_arn
    # Optionally, you can add other parameters such as session_name, external_id, etc.
    # session_name = "example-session"
  }
}
