def call() {
    dir('terraform/environments/dev/efs') {
                        sh """
                            terraform init \
                                -backend-config='bucket=${env.BUCKET_NAME}' \
                                -backend-config='region=${env.REGION}' \
                                -backend-config='key=${env.MAIN_FOLDER}/backend/efs' \
                                -backend-config='role_arn=${env.roleArn}' \
                                -reconfigure
                        """

                        def tfPlanCmd = "terraform plan -out=efs_tfplan --var-file=../../../variables/dev.tfvars"
                        sh tfPlanCmd
                        sh 'terraform show -no-color efs_tfplan > efs_tfplan.txt'
                        def autoApprove = env.AUTO_APPROVE.toBoolean()

                        // Check if autoApprove is false, then ask for manual approval
                        if (!autoApprove) {
                            def plan = readFile 'efs_tfplan.txt'
                            input message: "Do you want to apply the plan?",
                                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                        }
                        sh "terraform apply -input=false efs_tfplan > terraform_output.log"
            }
        }
    
