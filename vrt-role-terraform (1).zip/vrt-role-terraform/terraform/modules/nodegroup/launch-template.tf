resource "aws_launch_template" "eks_decimal" {
  count                  = 1
  name_prefix            = "${var.cluster_name}-lt-${var.node_groups_decimal[count.index].name}"
  description            = "Default Launch-Template"
  update_default_version = true

#  image_id = "ami-0f403e3180720dd7e"

#  instance_type = var.node_groups_decimal[count.index].instance_types

  block_device_mappings {
    device_name = "/dev/xvda"

    ebs {
      volume_size           = 20
      volume_type           = "gp3"
      delete_on_termination = true
      encrypted             = true
      kms_key_id            = data.terraform_remote_state.kms.outputs.key_arn
    }
  }

  monitoring {
    enabled = true
  }

  network_interfaces {
    delete_on_termination = true
    security_groups       = [
      aws_security_group.node_group_sg[count.index].id,                       
      data.terraform_remote_state.eks.outputs.eks_allow_vpc_cidr_sg_id,      
      data.terraform_remote_state.eks.outputs.eks_cluster_sg_id              
    ]
  }

  tag_specifications {
    resource_type = "instance"

    tags = {
      Name      = "${var.cluster_name}-decimal"
      CustomTag = "Instance custom tag"
    }
  }

  tag_specifications {
    resource_type = "volume"

    tags = {
      CustomTag = "Volume custom tag"
    }
  }

  tag_specifications {
    resource_type = "network-interface"

    tags = {
      CustomTag = "${var.cluster_name}-lt-${var.node_groups_decimal[count.index].name}"
    }
  }

  tags = {
    CustomTag = "Launch template custom tag"
  }

  lifecycle {
    create_before_destroy = true
  }
}