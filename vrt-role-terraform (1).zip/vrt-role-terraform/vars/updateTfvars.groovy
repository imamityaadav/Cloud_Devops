def call() {
    def tfvarsPath = 'terraform/variables/dev.tfvars'

    // Read the existing content of the tfvars file
    def tfvarsContent = readFile(file: tfvarsPath)

    // Create a map with the new variable values
    def newVars = [
        'backend_bucket'                   : "\"${env.BUCKET_NAME}\"",
        'backend_path'                     : "\"${env.MAIN_FOLDER}\"",
        'account_id'                     : "\"${env.ACCOUNT_ID}\"",
        'vpc_cidr'                         : "\"${env.VPC_CIDR}\"",
        'vpc_tags'                         : "${env.VPC_TAGS}",
        'role_arn'                         : "\"${env.roleArn}\"",
        'lb_tags'                          : "${env.LB_TAGS}",
        'kms_tags'                         : "${env.KMS_TAGS}",
        'jumpbox_tags'                     : "${env.JUMPBOX_TAGS}",
        'efs_tags'                         : "${env.EFS_TAGS}",
        'eks_tags'                         : "${env.EKS_TAGS}",
        'rds_tags'                         : "${env.RDS_TAGS}",
        'elasticache_tags'                 : "${env.REDIS_TAGS}",
        'public-count'                     : "${env.PUBLIC_SUBNET}",
        'private-count'                    : "${env.PRIVATE_SUBNET}",
        'public-subnet_mask'               : "\"${env.PUBLIC_SUBNET_MASK}\"",
        'private-subnet_mask'              : "\"${env.PRIVATE_SUBNET_MASK}\"",
        'environment'                      : "\"${env.ENVIRONMENT}\"",
        'region'                           : "\"${env.REGION}\"",
        'internal'                         : env.INTERNAL,  // Already converted to string
        'load_balancer_type'               : "\"${env.LOAD_BALANCER_TYPE}\"",
        'load_balancer_name'               : "\"${env.LOAD_BALANCER_NAME}\"",
        'security_group'                   : "\"${env.SECURITY_GROUP}\"",
        'lb-port'                          : env.LB_PORT,  // Already converted to string
        'protocol'                         : "\"${env.PROTOCOL}\"",  // Fixed spelling
        'target-group-name'                : "\"${env.TARGET_GROUP_NAME}\"",
        'lb_security_group'                : "\"${env.LB_SECURITY_GROUP}\"",
        'from_ports'                       : env.FROM_PORTS,  // Already converted to string
        'to_ports'                         : env.TO_PORTS,  // Already converted to string
        'security-group-cidr'              : "\"${env.SECURITY_GROUP_CIDR}\"",
        'kms_key_name'                     : "\"${env.KMS_NAME}\"",
        'cluster-name'                     : "\"${env.CLUSTER_NAME}\"",
        'tool-max-workers-decimal1'        : "\"${params.tool_max_workers_decimal1}\"",
        'app-max-workers-decimal0'         : "\"${params.app_max_workers_decimal0}\"",
        'nginx-max-workers-decimal2'       : "\"${params.nginx_max_workers_decimal2}\"",
        'cust-app-max-workers-decimal3'    : "\"${params.cust_app_max_workers_decimal3}\"",
        'redis-max-workers-decimal4'       : "\"${params.redis_max_workers_decimal4}\"",
        'observability-max-workers-decimal5'    : "\"${params.observability_max_workers_decimal5}\"",
        'cloudwatch_logs'                  : env.CLOUDWATCH_LOGS,
        'cluster-autoscaler'               : env.CLUSTER_AUTOSCALER,
        'node_groups_decimal0'             : "${params.app_node_groups_decimal0}",
        'node_groups_decimal1'             : "${params.tool_node_groups_decimal1}",
        'node_groups_decimal2'             : "${params.nginx_node_groups_decimal2}",
        'node_groups_decimal3'             : "${params.cust_app_node_groups_decimal3}",
        'node_groups_decimal4'             : "${params.redis_node_groups_decimal4}",
        'node_groups_decimal5'             : "${params.observability_node_groups_decimal5}",
        'count_decimal0'                   : params.count_decimal0.toString(),
        'count_decimal1'                   : params.count_decimal1.toString(),
        'count_decimal2'                   : params.count_decimal2.toString(),
        'count_decimal3'                   : params.count_decimal3.toString(),
        'count_decimal4'                   : params.count_decimal4.toString(),
        'count_decimal5'                   : params.count_decimal5.toString(),
        'node-ami-decimal0'                : "\"${params.node_ami_decimal0}\"",
        'node-ami-decimal1'                : "\"${params.node_ami_decimal1}\"",
        'instance_capacity_types_decimal1' : "\"${params.instance_capacity_types_decimal1}\"",
        'instance_capacity_types_decimal0' : "\"${params.instance_capacity_types_decimal0}\"",
        'instance_capacity_types_decimal2' : "\"${params.instance_capacity_types_decimal2}\"",
        'instance_capacity_types_decimal3' : "\"${params.instance_capacity_types_decimal3}\"",
        'instance_capacity_types_decimal4' : "\"${params.instance_capacity_types_decimal4}\"",
        'instance_capacity_types_decimal5' : "\"${params.instance_capacity_types_decimal5}\"",
        'inst_disk_size'                   : "\"${params.node_instance_disk_size}\"",
        'inst_key_pair'                    : params.node_instance_key_pair,
        'app-min-workers-decimal0'         : "\"${params.app_min_workers_decimal0}\"",
        'tool-min-workers-decimal1'        : "\"${params.tool_min_workers_decimal1}\"",
        'nginx-min-workers-decimal2'       : "\"${params.nginx_min_workers_decimal2}\"",
        'cust-app-min-workers-decimal3'    : "\"${params.cust_app_min_workers_decimal3}\"",
        'redis-min-workers-decimal4'       : "\"${params.redis_min_workers_decimal4}\"",
        'observability-min-workers-decimal5'    : "\"${params.observability_min_workers_decimal5}\"",
        'app-desired-workers-decimal0'     : "\"${params.app_desired_workers_decimal0}\"",
        'tool-desired-workers-decimal1'    : "\"${params.tool_desired_workers_decimal1}\"",
        'nginx-desired-workers-decimal2'   : "\"${params.nginx_desired_workers_decimal2}\"",
        'cust-app-desired-workers-decimal3' : "\"${params.cust_app_desired_workers_decimal3}\"",
        'redis-desired-workers-decimal4'   : "\"${params.redis_desired_workers_decimal4}\"",
        'observability-desired-workers-decimal5'    : "\"${params.observability_desired_workers_decimal5}\"",
        'k8s_version'                      : "\"${env.K8S_VERSION}\"",
        'instance-type-on-decimal1'        : params.instance_type_decimal1,
        'instance-type-decimal0'           : params.instance_type_decimal0,
        'instance-type-decimal2'           : params.instance_type_decimal2,
        'instance-type-on-decimal3'        : params.instance_type_decimal3,
        'instance-type-decimal4'           : params.instance_type_decimal4,
        'instance-type-decimal5'           : params.instance_type_decimal5,
        'public_key_file'                  : "\"${params.public_key_file}\"",
        'ami'                              : "\"${env.JUMPBOX_AMI}\"",
        'ec2_key_name'                     : "\"${env.JUMOBOX_NAME}\"",
        'ec2_instance_type'                : "\"${env.JUMPBOX_INSTANCE_TYPE}\"",
        'vrt_db_instance_identifier'       : "\"${env.DB_IDENTIFIER}\"",
        'vrt_db_security_group'            : "\"${env.DB_SECURITY_GROUP}\"",
        'vrt__db_cidr_range'               : "\"${env.DB_SG_RANGE}\"",
        'major_version'                    : "\"${env.DB_MAJOR_VERSION}\"",
        'vrt_db_allocated_storage'         : "\"${env.DB_STORAGE}\"",
        'engine_version'                   : "\"${env.DB_ENGINE_VERSION}\"",
        'vrt_db_instance_type'             : "\"${env.DB_INSTANCE_TYPE}\"",
        'vrt_database_name'                : "\"${env.DB_NAME}\"",
        'database_user'                    : "\"${env.DB_USER}\"",
        'database_password'                : "\"${env.DB_USER_PASSWORD}\"",
        'rds_port'                         : env.RDS_PORT,
        'rds_multi_az'                     : env.RDS_MULTI_AZ,
        'efs-security-group'               : "\"${env.EFS_SG}\"",
        'replication-id'                   : "\"${env.REDIS_REPLICATION_ID}\"",
        'redis-cluster'                    : "\"${env.REDIS_CLUSTER}\"",
        'redis-engine'                     : "\"${env.REDIS_ENGINE}\"",
        'redis-engine-version'             : "\"${env.REDIS_ENGINE_VERSION}\"",
        'redis_password'                   : "\"${env.REDIS_PASSWORD}\"",
        'redis-node-type'                  : "\"${env.REDIS_NODE_TYPE}\"",
        'redis-user-name'                  : "\"${env.REDIS_USER_NAME}\"",
        'transit_encryption_enabled'       : env.REDIS_TRANSIT_ENCRYPTION,
        'redis_multi_az'                   : env.REDIS_MULTI_AZ,
        'redis_auto_failover'              : env.REDIS_AUTO_FAILOVER,
        'redis-user-id'                    : "\"${env.REDIS_USER_ID}\"",
        'rest_encryption'                  : env.REDIS_REST_ENCRYPTION,
        'parameter-group-family'           : "\"${env.REDIS_PARAMETER_GROUP_FAMILY}\"",
        'num-node-groups'                  : "\"${env.REDIS_NUM_NODES}\"",
        'num-cache-nodes'                  : "\"${env.NUM_CACHE_NODES}\"",
        'replicas-per-node-group'          : "\"${env.REDIS_REPLICAS_PER_NODE}\"",
        'redis_port'                       : env.REDIS_PORT
    ]

    // Check and update variables in tfvarsContent
    newVars.each { var, value ->
        def pattern = /${var}\s*=\s*(.*)/
        if (tfvarsContent =~ pattern) {
            tfvarsContent = tfvarsContent.replaceAll(pattern, "${var} = ${value}")
        } else {
            tfvarsContent += "\n${var} = ${value}"
        }
    }

    // Write the updated content back to the tfvars file
    writeFile(file: tfvarsPath, text: tfvarsContent)
}
