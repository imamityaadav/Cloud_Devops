def call() {
    dir('terraform/environments/dev/kubebench-secuirtyscore') {
        script {
            echo "Assuming role to obtain temporary credentials..."
            
            def assumeRoleOutput = sh(
                script: """
                    aws sts assume-role \
                    --role-arn ${env.roleArn} \
                    --role-session-name my-session \
                    --output json
                """,
                returnStdout: true
            ).trim()

            def roleCredentials = readJSON(text: assumeRoleOutput)
            def accessKeyId = roleCredentials.Credentials.AccessKeyId
            def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
            def sessionToken = roleCredentials.Credentials.SessionToken

            echo "Successfully assumed role. Temporary credentials obtained."

            // Export temporary credentials for AWS CLI commands and pass to Ansible
            withEnv([
                "AWS_ACCESS_KEY_ID=${accessKeyId}",
                "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
                "AWS_SESSION_TOKEN=${sessionToken}"
            ]) {
                def ec2Name = env.JUMOBOX_NAME
                echo "Retrieving EC2 public IP for instance with Name tag: ${ec2Name} in region: ${env.REGION}"

                def instancePublicIp = sh(
                    returnStdout: true,
                    script: """
                        aws ec2 describe-instances \
                            --filters "Name=tag:Name,Values=${ec2Name}" \
                            --query 'Reservations[*].Instances[*].PublicIpAddress' \
                            --output text --region ${env.REGION}
                    """
                ).trim()

                echo "AWS CLI returned public IP: ${instancePublicIp}"

                if (instancePublicIp && instancePublicIp != "None") {
                    echo "Retrieved EC2 public IP: ${instancePublicIp}"
                } else {
                    error "Failed to retrieve the public IP address for EC2 instance: ${ec2Name}."
                }

                def inventoryContent = """
                [ec2]
                ${instancePublicIp} ansible_user=${env.EC2_USER_NAME} ansible_ssh_private_key_file=/var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem
                """

                writeFile file: 'inventory.ini', text: inventoryContent.trim()
                echo "Generated Ansible inventory file:"
                sh "cat inventory.ini"

                // Run Ansible playbook, passing credentials as extra-vars
                sh """
                    ansible-playbook -i inventory.ini deploy.yml \
                    --extra-vars 'aws_access_key_id=${accessKeyId} aws_secret_access_key=${secretAccessKey} aws_session_token=${sessionToken} username=${env.EC2_USER_NAME} aws_region=${env.REGION} cluster_name=${env.CLUSTER_NAME} namespace=${env.NAMESPACE}'
                """
            }
        }
    }
}
