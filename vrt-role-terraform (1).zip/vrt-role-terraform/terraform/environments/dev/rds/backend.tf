terraform {
  backend "s3" {
    bucket     = var.backend_bucket
    key        = "${var.backend_path}/backend/rds"
    region     = var.region
    role_arn   = var.role_arn
  }
}

