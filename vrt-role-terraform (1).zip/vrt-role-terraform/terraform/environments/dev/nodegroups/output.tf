output "eks_node_role_arn" {
  description = "The ARN of the EKS node role"
  value       = module.nodegroup.eks_node_role_arn
}

output "eks_key_pair_name" {
  description = "The name of the EKS key pair"
  value       = module.nodegroup.eks_key_pair_name
}

###output "efs_security_group_id" {
###  description = "The ID of the security group for EFS mount targets"
###  value       = module.nodegroup.efs_security_group_id
###}

output "tls_private_key_ssh_server_eks" {
  description = "The private key for the SSH server on EKS"
  sensitive = true
  value       = module.nodegroup.tls_private_key_ssh_server_eks
}

#output "eks_node_group_names" {
#  description = "The names of all EKS node groups"
#  value       = [for i in range(length(var.node_groups_decimal)) : aws_eks_node_group.decimal[i].node_group_name]
#}

#output "eks_node_group_arns" {
#  description = "The ARNs of all EKS node groups"
#  value       = [for i in range(length(var.node_groups_decimal)) : aws_eks_node_group.decimal[i].arn]
#}

#output "eks_node_group_autoscaling_groups" {
#  description = "The autoscaling groups associated with each EKS node group"
#  value       = [for i in range(length(var.node_groups_decimal)) : aws_eks_node_group.decimal[i].resources[0].autoscaling_groups[0].name]
#}
