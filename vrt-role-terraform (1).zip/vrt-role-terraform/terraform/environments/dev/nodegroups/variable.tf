variable "cluster_name" {
  description = "The name of the EKS cluster"
  type        = string
}

variable "cloudwatch_logs" {
  type        = bool
  description = "Setup full CloudWatch logging."
}

variable "public_key_file" {
  type        = string
  description = "File path to the public key file."
}

variable "backend_path" {
  type        = string
  description = "File path to the backend key file."
}


variable "eks_key_name" {
  type        = string
  description = "(Optional) The name of the SSH key pair to use for the EKS worker instances."
}

variable "environment" {
  type        = string
  description = "The environment name (e.g., production, staging)."
}

variable "role_arn" {
  type = string
  description = "aws iam role"
}


variable "region" {
  type        = string
  description = "The AWS region to deploy the EKS cluster."
}

variable "backend_bucket" {
  type        = string
  description = "The S3 bucket for backend state storage."
}

variable "node_groups_decimal" {
  description = "List of node groups with specific ingress and egress rules"
  type = list(object({
    name            = string
    instance_types  = list(string)
    ng_decimal_tags = map(string)
    labels          = map(string)
    tolerations     = object({
      key    = string
      value  = string
      effect = string
    })
    minimum_size    = number
    maximum_size    = number
    desired_size    = number
    capacity_type   = string
    inst_disk_size  = number

    # Ingress and egress rules for each node group
    ingress_rules = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))

    egress_rules = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))
  }))
}

variable "node_groups_decimal_tt" {
  description = "List of node groups with specific ingress and egress rules"
  type = list(object({
    name            = string
    instance_types  = list(string)
    ng_decimal_tags = map(string)
    labels          = map(string)
    minimum_size    = number
    maximum_size    = number
    desired_size    = number
    capacity_type   = string
    inst_disk_size  = number

    # Ingress and egress rules for each node group
    ingress_rules = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))

    egress_rules = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))
  }))
}
