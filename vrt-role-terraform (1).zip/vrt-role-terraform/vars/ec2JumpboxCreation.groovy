def call() {
    dir('terraform/environments/dev/ec2-jumpbox') {
        // Terraform initialization with backend configuration
        sh """
            terraform init \
                -backend-config='bucket=${env.BUCKET_NAME}' \
                -backend-config='region=${env.REGION}' \
                -backend-config='key=${env.MAIN_FOLDER}/backend/ec2-jumpbox' \
                -backend-config='role_arn=${env.roleArn}' \
                -reconfigure
        """

        // Set permissions for the Jenkins workspace directory
        sh """#!/bin/bash
            chmod 777 /var/lib/jenkins/workspace/${env.PIPELINE_NAME}
        """

        // Assume role to get temporary credentials
        def assumeRoleOutput = sh(script: """
            aws sts assume-role \
                --role-arn ${env.roleArn} \
                --role-session-name my-session \
                --output json
        """, returnStdout: true).trim()

        def roleCredentials = readJSON(text: assumeRoleOutput)
        def accessKeyId = roleCredentials.Credentials.AccessKeyId
        def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
        def sessionToken = roleCredentials.Credentials.SessionToken

        // Export temporary credentials for AWS CLI commands
        withEnv([
            "AWS_ACCESS_KEY_ID=${accessKeyId}",
            "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
            "AWS_SESSION_TOKEN=${sessionToken}"
        ]) {
            // Check or create key pair and upload to S3
            sh """#!/bin/bash
                if aws ec2 describe-key-pairs --key-names ${env.JUMOBOX_NAME} --region ${env.REGION} > /dev/null 2>&1; then
                    echo "Key pair ${env.JUMOBOX_NAME} already exists. Continuing..."
                else
                    echo "Creating key pair ${env.JUMOBOX_NAME}..."
                    aws ec2 create-key-pair --key-name ${env.JUMOBOX_NAME} --query 'KeyMaterial' --output text --region ${env.REGION} > ${env.JUMOBOX_NAME}.pem
                    echo "Key pair ${env.JUMOBOX_NAME} created successfully."
                    
                    echo "Uploading key pair to S3..."
                    aws s3 cp ${env.JUMOBOX_NAME}.pem s3://${env.BUCKET_NAME}/${env.MAIN_FOLDER}/keys/${env.JUMOBOX_NAME}.pem --region ${env.REGION}
                    echo "Key pair uploaded to S3 bucket ${env.BUCKET_NAME} successfully."
                fi
            """
        }

        // Generate Terraform plan
        def tfPlanCmd = "terraform plan -out=ec2_jumpbox_tfplan --var-file=../../../variables/dev.tfvars"
        sh tfPlanCmd

        // Display plan and handle approval if required
        sh 'terraform show -no-color ec2_jumpbox_tfplan > ec2_jumpbox_tfplan.txt'
        def autoApprove = env.AUTO_APPROVE.toBoolean()

        if (!autoApprove) {
            def plan = readFile('ec2_jumpbox_tfplan.txt')
            input message: "Do you want to apply the plan?",
                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
        }

        // Apply Terraform plan
        sh "terraform apply -input=false ec2_jumpbox_tfplan > terraform_output.log"
    }
}
