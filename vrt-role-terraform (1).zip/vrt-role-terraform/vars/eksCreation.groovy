def call() {
    dir('terraform/environments/dev/eks') {
                        sh """
                            terraform init \
                                -backend-config='bucket=${env.BUCKET_NAME}' \
                                -backend-config='region=${env.REGION}' \
                                -backend-config='key=${env.MAIN_FOLDER}/backend/eks' \
                                -backend-config='role_arn=${env.roleArn}' \
                                -reconfigure
        """

                        def tfPlanCmd = "terraform plan -out=eks_tfplan --var-file=../../../variables/dev.tfvars"
                        sh tfPlanCmd
                        sh 'terraform show -no-color eks_tfplan > eks_tfplan.txt'
                        def autoApprove = env.AUTO_APPROVE.toBoolean()

                        // Check if autoApprove is false, then ask for manual approval
                        if (!autoApprove) {
                            def plan = readFile 'eks_tfplan.txt'
                            input message: "Do you want to apply the plan?",
                                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                        }
                        sh "terraform apply -input=false eks_tfplan > terraform_output.log"
            }
        }
