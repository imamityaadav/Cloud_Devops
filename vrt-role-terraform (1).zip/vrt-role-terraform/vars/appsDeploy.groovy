def call() {
    dir('terraform/environments/dev/Apps') {
        script {
            echo "Assuming role to obtain temporary credentials..."

            // Assume the role and get temporary credentials
            def assumeRoleOutput = sh(
                script: """
                    aws sts assume-role \
                    --role-arn ${env.roleArn} \
                    --role-session-name my-session \
                    --output json
                """,
                returnStdout: true
            ).trim()

            def roleCredentials = readJSON(text: assumeRoleOutput)
            def accessKeyId = roleCredentials.Credentials.AccessKeyId
            def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
            def sessionToken = roleCredentials.Credentials.SessionToken

            echo "Successfully assumed role. Temporary credentials obtained."

            // Use the temporary credentials for subsequent AWS CLI commands
            withEnv([
                "AWS_ACCESS_KEY_ID=${accessKeyId}",
                "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
                "AWS_SESSION_TOKEN=${sessionToken}"
            ]) {
                // Bucket creation and folder setup
                echo "Checking and creating S3 bucket: ${env.DMS_BUCKET_NAME}..."
                sh """#!/bin/bash
                if aws s3api head-bucket --bucket ${env.DMS_BUCKET_NAME} --region ${env.REGION} > /dev/null 2>&1; then
                    echo "Bucket ${env.DMS_BUCKET_NAME} already exists. Continuing..."
                else
                    echo "Creating bucket ${env.DMS_BUCKET_NAME}..."
                    if [ "${env.REGION}" != "us-east-1" ]; then
                        aws s3api create-bucket --bucket ${env.DMS_BUCKET_NAME} --region ${env.REGION} --create-bucket-configuration LocationConstraint=${env.REGION}
                    else
                        aws s3api create-bucket --bucket ${env.DMS_BUCKET_NAME} --region ${env.REGION}
                    fi
                    echo "Bucket ${env.DMS_BUCKET_NAME} created successfully."
                fi
                """

                // EC2 public IP retrieval
                def ec2Name = env.JUMOBOX_NAME
                echo "Retrieving EC2 public IP for instance with Name tag: ${ec2Name} in region: ${env.REGION}"
                def instancePublicIp = sh(
                    returnStdout: true,
                    script: """
                        aws ec2 describe-instances \
                            --filters "Name=tag:Name,Values=${ec2Name}" \
                            --query 'Reservations[*].Instances[*].PublicIpAddress' \
                            --output text --region ${env.REGION}
                    """
                ).trim()
                if (instancePublicIp && instancePublicIp != "None") {
                    echo "Retrieved EC2 public IP: ${instancePublicIp}"
                } else {
                    error "Failed to retrieve the public IP address for EC2 instance: ${ec2Name}. Please ensure the instance has a public IP and the Name tag matches."
                }

                // Redis primary endpoint retrieval
                def redisEndpoint = sh(
                    returnStdout: true,
                    script: """
                        aws elasticache describe-replication-groups \
                            --replication-group-id ${env.REDIS_REPLICATION_ID} \
                            --query "ReplicationGroups[0].NodeGroups[0].PrimaryEndpoint.Address" \
                            --output text --region ${env.REGION}
                    """
                ).trim()
                if (redisEndpoint && redisEndpoint != "None") {
                    echo "Retrieved Redis primary endpoint: ${redisEndpoint}"
                } else {
                    error "Failed to retrieve the Redis primary endpoint for cluster: ${env.REDIS_CLUSTER}. Please ensure the cluster exists and the ID is correct."
                }

                // Generate Ansible inventory.ini
                def inventoryContent = """
                [ec2]
                ${instancePublicIp} ansible_user=${env.EC2_USER_NAME} ansible_ssh_private_key_file=/var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem

                [redis]
                redis_endpoint=${redisEndpoint}
                """
                writeFile file: 'inventory.ini', text: inventoryContent.trim()
                echo "Generated Ansible inventory file:"
                sh "cat inventory.ini"

                // Run Ansible playbook
                sh """
                    ansible-playbook -i inventory.ini deploy.yml \
                        --extra-vars 'username=${env.EC2_USER_NAME} \
                        cluster_name=${env.CLUSTER_NAME} \
                        DMS_S3_BUCKET=${env.DMS_BUCKET_NAME} \
                        DMS_SECRET_KEY=${env.DMS_SECRET_KEY} \
                        DMS_ACCESS_KEY=${env.DMS_ACCESS_KEY} \
                        redis_host=${redisEndpoint} \
                        redis_password=${env.REDIS_PASSWORD} \
                        redis_port=${env.REDIS_PORT} \
                        aws_access_key_id=${accessKeyId} \
                        aws_secret_access_key=${secretAccessKey} \
                        aws_session_token=${sessionToken} \
                        aws_region=${env.REGION} \
                        aws_output_format=${env.OUTPUT_FORMAT} \
                        role_arn=${env.roleArn} \
                        namespace=${env.NAMESPACE}'
                """
            }
        }
    }
}
