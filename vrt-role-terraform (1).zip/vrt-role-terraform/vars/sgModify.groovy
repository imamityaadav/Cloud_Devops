def call() {
    // Define variables for Security Group and rule parameters
    def securityGroupId = env.SECURITY_GROUP_ID
    def protocol = env.SG_MODIFY_PROTOCOL
    def port = env.SG_MODIFY_PORT
    def cidrBlock = env.SG_MODIFY_CIDR

    // Assume Role and set temporary credentials
    def assumeRoleOutput = sh(script: """
        aws sts assume-role \
            --role-arn ${env.ROLE_ARN} \
            --role-session-name my-session \
            --output json
    """, returnStdout: true).trim()

    def roleCredentials = readJSON(text: assumeRoleOutput)
    def accessKeyId = roleCredentials.Credentials.AccessKeyId
    def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
    def sessionToken = roleCredentials.Credentials.SessionToken

    // Export the temporary credentials as environment variables
    withEnv([
        "AWS_ACCESS_KEY_ID=${accessKeyId}",
        "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
        "AWS_SESSION_TOKEN=${sessionToken}"
    ]) {
        sh """#!/bin/bash

        # Jenkins Pipeline Shell Script for Adding Security Group Rule
        echo "### Adding Rule to Security Group ###"

        aws ec2 authorize-security-group-ingress \
            --group-id ${securityGroupId} \
            --protocol ${protocol} \
            --port ${port} \
            --cidr ${cidrBlock}

        if [ $? -eq 0 ]; then
            echo "Rule added successfully to Security Group: ${securityGroupId}"
        else
            echo "Failed to add rule to Security Group: ${securityGroupId}"
            exit 1
        fi
        """
    }
}
