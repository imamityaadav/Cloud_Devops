// vars/notifyStage.groovy
def call(String stageName, String buildStatus = 'SUCCESS') {
    def color = buildStatus == 'SUCCESS' ? '#36a64f' : '#FF0000'
    def consoleOutput = ''

    if (buildStatus == 'FAILURE') {
        // Retrieve console output only for failures
        consoleOutput = getConsoleOutput(stageName)
    }

    // Replace this with your Google Chat webhook URL
    def googleChatWebhook = "https://chat.googleapis.com/v1/spaces/AAAAL7xm2hU/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=OqpNP8aIxNpHXEwawWDfGoQCdZCDw5yyOxGCSJin9RM"

    def message = [
        text: "Build Notification:\n" +
              "Stage: *${stageName}*\n" +
              "Status: *${buildStatus}*\n" +
              (buildStatus == 'FAILURE' ? "Console Output:\n```\n${consoleOutput}\n```" : "")
    ]

    // Send the notification
    httpRequest(
        httpMode: 'POST',
        contentType: 'APPLICATION_JSON',
        requestBody: groovy.json.JsonOutput.toJson(message),
        url: googleChatWebhook
    )
}

def getConsoleOutput(String stageName) {
    // Retrieve the console output of the specific stage
    def log = currentBuild.rawBuild.getLog(1000)
    def stageLogs = log.findAll { it.contains(stageName) }
    return stageLogs.join('\n').take(1000) // Limiting to 1000 characters
}
