module "nodegroup" {
  source                           = "../../../modules/nodegroup"
  cloudwatch_logs                  = var.cloudwatch_logs
  cluster_name                     = var.cluster_name
  public_key_file                  = var.public_key_file
  eks_key_name                     = var.eks_key_name
  environment                      = var.environment
  region                           = var.region
  backend_bucket                   = var.backend_bucket
  node_groups_decimal              = var.node_groups_decimal
  node_groups_decimal_tt           = var.node_groups_decimal_tt
  backend_path                     = var.backend_path
  role_arn                         = var.role_arn

}