def call() {
    dir('terraform/environments/dev/addon') {
                        sh "terraform init"
                        def tfPlanCmd = "terraform plan -out=as_tfplan --var-file=../../../variables/dev.tfvars"
                        sh tfPlanCmd
                        sh 'terraform show -no-color as_tfplan > as_tfplan.txt'
                        def autoApprove = env.AUTO_APPROVE.toBoolean()

                        // Check if autoApprove is false, then ask for manual approval
                        if (!autoApprove) {
                            def plan = readFile 'as_tfplan.txt'
                            input message: "Do you want to apply the plan?",
                                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
                        }
                        sh "terraform apply -input=false as_tfplan"
            }
        }
