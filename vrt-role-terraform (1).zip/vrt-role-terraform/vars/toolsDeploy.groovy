def call() {
    dir('terraform/environments/dev/Tools') {
        script {
            echo "Assuming role to obtain temporary credentials..."

            // Assume the role and get temporary credentials
            def assumeRoleOutput = sh(
                script: """
                    aws sts assume-role \
                    --role-arn ${env.roleArn} \
                    --role-session-name my-session \
                    --output json
                """,
                returnStdout: true
            ).trim()

            def roleCredentials = readJSON(text: assumeRoleOutput)
            def accessKeyId = roleCredentials.Credentials.AccessKeyId
            def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
            def sessionToken = roleCredentials.Credentials.SessionToken

            echo "Successfully assumed role. Temporary credentials obtained."

            // Use the temporary credentials for subsequent AWS CLI commands
            withEnv([
                "AWS_ACCESS_KEY_ID=${accessKeyId}",
                "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
                "AWS_SESSION_TOKEN=${sessionToken}"
            ]) {
                def ec2Name = env.JUMOBOX_NAME
                echo "Retrieving EC2 public IP for instance with Name tag: ${ec2Name} in region: ${env.REGION}"

                // Retrieve EC2 public IP
                def instancePublicIp = sh(
                    returnStdout: true,
                    script: """
                        aws ec2 describe-instances \
                            --filters "Name=tag:Name,Values=${ec2Name}" \
                            --query 'Reservations[*].Instances[*].PublicIpAddress' \
                            --output text --region ${env.REGION}
                    """
                ).trim()

                // Check if the EC2 IP was successfully retrieved
                if (instancePublicIp && instancePublicIp != "None") {
                    echo "Retrieved EC2 public IP: ${instancePublicIp}"
                } else {
                    error "Failed to retrieve the public IP address for EC2 instance: ${ec2Name}. Please ensure the instance has a public IP and the Name tag matches."
                }

                // Retrieve EFS ID
                def efsName = "${env.EFS_NAME}"
                def efsId = sh(
                    returnStdout: true,
                    script: """
                        aws efs describe-file-systems \
                            --query "FileSystems[?Tags[?Key=='Name' && Value=='${efsName}']].FileSystemId" \
                            --output text --region ${env.REGION}
                    """
                ).trim()

                // Check if the EFS ID was successfully retrieved
                if (efsId && efsId != "None") {
                    echo "Retrieved EFS ID: ${efsId}"
                } else {
                    error "Failed to retrieve the EFS ID for EFS Name: ${efsName}. Please ensure the EFS exists with the specified name tag."
                }

                // Construct the EFS DNS name
                def efsDnsName = "${efsId}.efs.${env.REGION}.amazonaws.com"
                echo "Constructed EFS DNS Name: ${efsDnsName}"

                // Generate Ansible inventory.ini content
                def inventoryContent = """
                [ec2]
                ${instancePublicIp} ansible_user=${env.EC2_USER_NAME} ansible_ssh_private_key_file=/var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem

                [efs]
                efs_id=${efsId}
                efs_dns=${efsDnsName}
                """

                // Create the inventory.ini file
                writeFile file: 'inventory.ini', text: inventoryContent.trim()

                // Display the content of the generated inventory.ini file
                echo "Generated Ansible inventory file:"
                sh "cat inventory.ini"

                // Run Ansible playbook using the generated inventory.ini file
                echo "Running Ansible playbook..."
                sh """
                    ansible-playbook -i inventory.ini deploy.yml \
                        --extra-vars 'username=${env.EC2_USER_NAME} \
                        efs_id=${efsId} \
                        aws_access_key_id=${accessKeyId} \
                        aws_secret_access_key=${secretAccessKey} \
                        aws_session_token=${sessionToken} \
                        aws_region=${env.REGION} \
                        namespace=${env.NAMESPACE} \
                        consul_version=${env.CONSUL_VERSION} \
                        elasticsearch_version=${env.ELASTICSEARCH_VERSION} \
                        kafka_version=${env.KAFKA_VERSION} \
                        nginx_ic_version=${env.NGINX_VERSION} \
                        logstash_version=${env.LOGSTASH_VERSION}'
                """
            }
        }
    }
}
