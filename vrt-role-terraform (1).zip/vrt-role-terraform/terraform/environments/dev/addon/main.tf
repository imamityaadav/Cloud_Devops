resource "aws_eks_addon" "coredns" {
  cluster_name                = var.cluster-name
  addon_name                  = "coredns"
  addon_version               = "v1.11.4-eksbuild.2"
  resolve_conflicts_on_update = "PRESERVE" # or "OVERRIDE" depending on your preference
}

resource "aws_eks_addon" "kube_proxy" {
  cluster_name                = var.cluster-name
  addon_name                  = "kube-proxy"
  addon_version               = "v1.31.3-eksbuild.2"
  resolve_conflicts_on_update = "PRESERVE" # or "OVERRIDE" depending on your preference
}

resource "aws_eks_addon" "ebs_csi_driver" {
  cluster_name                = var.cluster-name
  addon_name                  = "aws-ebs-csi-driver"
  addon_version               = "v1.38.1-eksbuild.1"
  resolve_conflicts_on_update = "PRESERVE" # or "OVERRIDE" depending on your preference
}

resource "aws_eks_addon" "efs_csi_driver" {
  cluster_name                = var.cluster-name
  addon_name                  = "aws-efs-csi-driver"
  addon_version               = "v2.1.3-eksbuild.1"
  resolve_conflicts_on_update = "PRESERVE" # or "OVERRIDE" depending on your preference
}
resource "aws_eks_addon" "vpc_cni" {
  cluster_name                = var.cluster-name
  addon_name                  = "vpc-cni"
  addon_version               = "v1.19.2-eksbuild.1"
  resolve_conflicts_on_update = "PRESERVE" # or "OVERRIDE" depending on your preference
}
