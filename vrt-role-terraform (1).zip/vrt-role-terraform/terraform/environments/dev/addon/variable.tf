variable "cluster-name" {
  type        = string
  description = "eks-cluster name for add on"
}

variable "region" {
  type = string
}


variable "role_arn" {
  type = string
  description = "aws iam role"
}
