def call() {
    dir('terraform/environments/dev/kms') {
        // Initialize Terraform
        sh "echo no | terraform init -backend-config='bucket=${env.BUCKET_NAME}' -backend-config='key=${env.MAIN_FOLDER}/backend/kms' -backend-config='region=${env.REGION}' -backend-config='role_arn=${env.roleArn}' -reconfigure "
        
        // Plan and generate a Terraform plan file
        def tfPlanCmd = "terraform plan -out=kms_tfplan --var-file=../../../variables/dev.tfvars"
        sh tfPlanCmd
        sh 'terraform show -no-color kms_tfplan > kms_tfplan.txt'
        
        def autoApprove = env.AUTO_APPROVE.toBoolean()

        // Check if autoApprove is false, then ask for manual approval
        if (!autoApprove) {
            def plan = readFile 'kms_tfplan.txt'
            input message: "Do you want to apply the plan?",
                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
        }

        // Apply the Terraform plan
        sh "terraform apply -input=false kms_tfplan > terraform_output.log"
        
        // Get the KMS Key ARN from Terraform output
        def kms_arn = sh(returnStdout: true, script: "terraform output key_arn").trim()
        env.kms_key_arn = kms_arn

        // Assume role to enable key rotation with assumed credentials
        def assumeRoleOutput = sh(script: """
            aws sts assume-role \
                --role-arn ${env.roleArn} \
                --role-session-name my-session \
                --output json
        """, returnStdout: true).trim()

        def roleCredentials = readJSON(text: assumeRoleOutput)
        def accessKeyId = roleCredentials.Credentials.AccessKeyId
        def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
        def sessionToken = roleCredentials.Credentials.SessionToken

        // Export temporary credentials and enable KMS key rotation
        withEnv([
            "AWS_ACCESS_KEY_ID=${accessKeyId}", 
            "AWS_SECRET_ACCESS_KEY=${secretAccessKey}", 
            "AWS_SESSION_TOKEN=${sessionToken}"
        ]) {
            sh "aws kms enable-key-rotation --key-id ${env.kms_key_arn} --region ${env.REGION} --rotation-period-in-days 90"
        }
    }
}
