def call() {
    dir('terraform/environments/dev/load_balancer') {
        sh "echo no | terraform init -backend-config='bucket=${env.BUCKET_NAME}' -backend-config='key=${env.MAIN_FOLDER}/backend/load_balancer' -backend-config='region=${env.REGION}' -backend-config='role_arn=${env.roleArn}' -reconfigure "
        def tfPlanCmd = "terraform plan -out=lb_tfplan --var-file=../../../variables/dev.tfvars"
        sh tfPlanCmd
        sh 'terraform show -no-color lb_tfplan > lb_tfplan.txt'
        def autoApprove = env.AUTO_APPROVE.toBoolean()

        // Check if autoApprove is false, then ask for manual approval
        if (!autoApprove) {
            def plan = readFile 'lb_tfplan.txt'
            input message: "Do you want to apply the plan?",
                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
        }
        sh "terraform apply -input=false lb_tfplan > terraform_output.log"
    }
}
