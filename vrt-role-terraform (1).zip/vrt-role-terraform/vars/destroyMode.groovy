def call() {
    def destroyMode = env.DESTROY_MODE.toBoolean()

    if (destroyMode) {
        echo "Executing in reverse order for destruction"

        // List of directories corresponding to each stage in reverse order
        def directories = [
            'terraform/environments/dev/elasticache',            // Stage 9
            'terraform/environments/dev/rds',                   // Stage 8
            'terraform/environments/dev/nodegroups',            // Stage 7
            'terraform/environments/dev/eks',                   // Stage 6
            'terraform/environments/dev/efs',                   // Stage 5
            'terraform/environments/dev/ec2-jumpbox',           // Stage 4
            'terraform/environments/dev/kms',                   // Stage 3
            'terraform/environments/dev/load_balancer',         // Stage 2
            'terraform/environments/dev/vpc'                    // Stage 1
        ]

        // Iterate over each directory in reverse order
        for (dirPath in directories) {
            dir(dirPath) {
                echo "Destroying resources in ${dirPath}"

                // Initialize Terraform
                sh """
                    terraform init \
                        -backend-config='bucket=${env.BUCKET_NAME}' \
                        -backend-config='key=${env.MAIN_FOLDER}/backend/${dirPath.split('/').last()}' \
                        -backend-config='region=${env.REGION}' \
                        -backend-config='role_arn=${env.roleArn}' \
                        -reconfigure
                """
                def jsonFilePath = "/var/lib/jenkins/workspace/curl-test/terraform/variables/payload.json"
                writeFile file: jsonFilePath, text: params.JSON_PAYLOAD

                println "JSON payload has been saved at: ${jsonFilePath}"


                // Choose the correct tfvars or JSON file
                def tfvarsFile = dirPath.contains('nodegroups') ? '../../../variables/payload.json' : '../../../variables/dev.tfvars'
                echo "Using ${tfvarsFile} for ${dirPath}"

                sh """
                    ls -l ${tfvarsFile}
                    terraform destroy -auto-approve -var-file=${tfvarsFile}
                """
            }
        }

        // Assume role and perform S3 operations
        echo "Assuming role: ${env.roleArn} for S3 operations"
        def assumeRoleCmd = """
            aws sts assume-role \
                --role-arn ${env.roleArn} \
                --role-session-name S3Operations \
                --region ${env.REGION} \
                --query 'Credentials.[AccessKeyId,SecretAccessKey,SessionToken]' \
                --output text
        """
        def credentials = sh(script: assumeRoleCmd, returnStdout: true).trim().split('\n')
        def accessKey = credentials[0].split()[0]
        def secretKey = credentials[0].split()[1]
        def sessionToken = credentials[0].split()[2]

        withEnv(["AWS_ACCESS_KEY_ID=${accessKey}", "AWS_SECRET_ACCESS_KEY=${secretKey}", "AWS_SESSION_TOKEN=${sessionToken}"]) {
            // Empty and delete the main S3 bucket
            try {
                echo "Emptying and deleting the S3 bucket: ${env.BUCKET_NAME}"
                sh """
                    aws s3 rm s3://${env.BUCKET_NAME} --recursive --region ${env.REGION}
                    aws s3api delete-bucket --bucket ${env.BUCKET_NAME} --region ${env.REGION}
                """
                echo "S3 bucket ${env.BUCKET_NAME} has been successfully deleted."
            } catch (Exception e) {
                error "Failed to delete S3 bucket ${env.BUCKET_NAME}: ${e.getMessage()}"
            }

            // Delete the AWS key pair
            try {
                echo "Deleting the AWS key pair: ${env.JUMOBOX_NAME}"
                sh """
                    aws ec2 delete-key-pair --key-name ${env.JUMOBOX_NAME} --region ${env.REGION}
                """
                echo "AWS key pair ${env.JUMOBOX_NAME} has been successfully deleted."
            } catch (Exception e) {
                error "Failed to delete AWS key pair ${env.JUMOBOX_NAME}: ${e.getMessage()}"
            }
        }

    } else {
        echo "Destroy mode is not enabled; skipping reverse execution."
    }
}