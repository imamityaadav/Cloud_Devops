def call() {
    dir('terraform/environments/dev/user-creation') {
        script {
            // Step 1: Assume the role and get temporary credentials
            echo "Assuming role: ${env.roleArn}"
            def assumeRoleOutput = sh(
                script: """
                    aws sts assume-role \
                    --role-arn ${env.roleArn} \
                    --role-session-name my-session \
                    --output json
                """, 
                returnStdout: true
            ).trim()

            def roleCredentials = readJSON(text: assumeRoleOutput)
            def accessKeyId = roleCredentials.Credentials.AccessKeyId
            def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
            def sessionToken = roleCredentials.Credentials.SessionToken

            echo "Successfully assumed role. Temporary credentials obtained."

            // Export temporary credentials for subsequent AWS CLI commands
            withEnv([
                "AWS_ACCESS_KEY_ID=${accessKeyId}",
                "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
                "AWS_SESSION_TOKEN=${sessionToken}"
            ]) {
                // Step 2: Download the key pair from S3
                echo "Downloading key pair from S3..."
                sh """
                    aws s3 cp s3://${env.BUCKET_NAME}/${env.MAIN_FOLDER}/keys/${env.JUMOBOX_NAME}.pem /var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem --region ${env.REGION}
                """
                sh "chmod 400 /var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem"

                // Step 3: Retrieve EC2 instance public IP based on Name tag
                def ec2Name = env.JUMOBOX_NAME
                echo "Retrieving EC2 public IP for instance with Name tag: ${ec2Name} in region: ${env.REGION}"

                def instancePublicIp = sh(
                    returnStdout: true,
                    script: """
                        aws ec2 describe-instances \
                            --filters "Name=tag:Name,Values=${ec2Name}" \
                            --query 'Reservations[*].Instances[*].PublicIpAddress' \
                            --output text --region ${env.REGION}
                    """
                ).trim()

                // Check if IP was successfully retrieved
                if (instancePublicIp && instancePublicIp != "None") {
                    echo "Retrieved EC2 public IP: ${instancePublicIp}"
                } else {
                    error "Failed to retrieve the public IP address for EC2 instance: ${ec2Name}. Please ensure the instance has a public IP and the Name tag matches."
                }

                // Step 4: Generate Ansible inventory.ini content
                def inventoryContent = """
                [ec2]
                ${instancePublicIp} ansible_user=ubuntu ansible_ssh_private_key_file=/var/lib/jenkins/key-pair/${env.JUMOBOX_NAME}.pem
                """
                writeFile file: 'inventory.ini', text: inventoryContent.trim()

                // Display the content of the generated inventory.ini file
                echo "Generated Ansible inventory file:"
                sh "cat inventory.ini"

                // Step 5: Run Ansible playbook using the dynamically created inventory file
                sh """
                    ansible-playbook -i inventory.ini deploy.yml \
                    --extra-vars 'password=${env.EC2_USER_PASSWORD} username=${env.EC2_USER_NAME}'
                """
            }
        }
    }
}
