#azs = ["us-east-1a", "us-east-1b"]

#azs = length(data.aws_availability_zones.available.names)

backend_bucket = "decimaltesting-01"

backend_path = "test"

role_arn = "arn:aws:iam::975050085624:role/terraform-testing"

vpc_cidr = "10.0.0.0/16"

vpc_tags = {Environment = "Prod"}

lb_tags = {Environment = "prod"}

kms_tags = {Environment = "prod"}

elasticache_tags = {Environment = "prod"}

eks_tags = {Environment = "prod"}

efs_tags = {Environment = "prod"}

jumpbox_tags = {Environment = "prod"}

rds_tags  = {Environment = "prod"}

public-count = 2

private-count = 2

nat-count = 2

public-subnet_mask = 4

private-subnet_mask = 4

environment = "prod"

region = "ap-south-1"

internal = false

load_balancer_type = "application"

load_balancer_name = "decimal-load-balancer"

security_group = "vpc-sg"

lb-port = 30023

protocol = "HTTP"

target-group-name = "tg-sg-lb"

lb_security_group = "load-balancer-sg"

from_ports = 443

to_ports = 443

security-group-cidr = "0.0.0.0/0"

kms_key_name = "decimal-vrt-kms-key"

cluster-name = "eks-decimal-cltr"

tool-max-workers-decimal1 = "2"

app-max-workers-decimal0 = "2"

nginx-max-workers-decimal2 = "2"

cust-app-max-workers-decimal3 = "2"

redis-max-workers-decimal4 = "2"

observability-max-workers-decimal5 = "2"

cloudwatch_logs = false

cluster-autoscaler = false

node_groups_decimal0 = [{ name = "pt-gf" }]

node_groups_decimal1 = [{ name = "pt-gf1" }]

node_groups_decimal2 = [{ name = "pt-gf" }]

node_groups_decimal3 = [{ name = "pt-gf1" }]

node_groups_decimal4 = [{ name = "pt-gf" }]

node_groups_decimal5 = [{ name = "pt-gf1" }]
count_decimal0 = 1
count_decimal1 = 1
count_decimal2 = 1
count_decimal3 = 1
count_decimal4 = 1
count_decimal5 = 1

node-ami-decimal0 = "ami-0f403e3180720dd7e"
node-ami-decimal1 = "ami-0f403e3180720dd7e"

instance_capacity_types_decimal1 = "ON_DEMAND"

instance_capacity_types_decimal0 = "ON_DEMAND"

instance_capacity_types_decimal3 = "ON_DEMAND"

instance_capacity_types_decimal2 = "ON_DEMAND"

instance_capacity_types_decimal4 = "ON_DEMAND"

instance_capacity_types_decimal5 = "ON_DEMAND"

inst_disk_size = "60"

inst_key_pair = null

app-min-workers-decimal0 = "1"

tool-min-workers-decimal1 = "1"

nginx-min-workers-decimal2 = "1"

cust-app-min-workers-decimal3 = "1"

redis-min-workers-decimal4 = "1"

observability-min-workers-decimal5 = "1"

app-desired-workers-decimal0 = "1"

tool-desired-workers-decimal1 = "1"

nginx-desired-workers-decimal2 = "1"

cust-app-desired-workers-decimal3 = "1"

redis-desired-workers-decimal4 = "1"

observability-desired-workers-decimal5 = "1"

k8s_version = "1.28"

instance-type-on-decimal1 = ["t3.medium", "t2.micro"]

instance-type-decimal0 = ["t3.medium", "t2.micro"]

instance-type-decimal2 = ["t3.medium", "t2.micro"]

instance-type-on-decimal3 = ["t3.medium", "t2.micro"]

instance-type-decimal4 = ["t3.medium", "t2.micro"]

instance-type-decimal5 = ["t3.medium", "t2.micro"]

public_key_file = "~/.ssh/id_rsa.pub"

ami = "ami-0f403e3180720dd7e"

ec2_key_name = "jumpbox-key-ec2"

ec2_instance_type = "t2.micro"

vrt_db_instance_identifier = "decimal-db-tech"

vrt_db_security_group = "decimal-rds-security"

vrt__db_cidr_range = "10.34.0.0/16"

major_version = "12"

vrt_db_allocated_storage = "20"

engine_version = "12.18"

vrt_db_instance_type = "db.m6g.large"

vrt_database_name = "decimal_database_technologies"

database_user = "psq_demo"

database_password = "Qwerty#789"

rds_port = 5432

rds_multi_az = true

efs-security-group = "efs-mount-target-sg"

replication-id = "decimal-elasticache-replication"

redis-cluster = "elasticache-redis-cluster"
redis-engine = "REDIS"

redis-engine-version = "7.0"

redis_password = "samepasswprdforredis"

redis-node-type = "cache.t3.small"

redis-user-name = "default"

transit_encryption_enabled = true

redis-user-id = "redis-user-dc"

redis-user-group = "test-user"

rest_encryption = true

num-cache-nodes = "1"

redis_multi_az = true

redis_auto_failover = true

parameter-group-family = "redis7"

num-node-groups = "1"

replicas-per-node-group = "1"

redis_port = 6379

js_user = "ec2-js-user"

eks_key_name = "eks-key"

account_id = "975050085624"

