terraform {
  backend "s3" {
    bucket     = var.backend_bucket
    key        = "${var.backend_path}/backend/ec2-jumpbox"
    region     = var.region
    role_arn   = var.role_arn
  }
}
