def call() {
    // Define variables for resources in Groovy
    def vpcName = env.VPC_NAME
    def lbName = env.LOAD_BALANCER_NAME
    def ec2InstanceName = env.JUMOBOX_NAME
    def efsName = env.EFS_NAME
    def eksClusterName = env.CLUSTER_NAME
    def rdsIdentifier = env.DB_IDENTIFIER
    def kmsAlias = "alias/eks-cluster-${env.KMS_NAME}-alias"
    def redisGroupId = env.REDIS_REPLICATION_ID

    // Assume Role and set temporary credentials
    def assumeRoleOutput = sh(script: """
        aws sts assume-role \
            --role-arn ${env.roleArn} \
            --role-session-name my-session \
            --output json
    """, returnStdout: true).trim()

    def roleCredentials = readJSON(text: assumeRoleOutput)
    def accessKeyId = roleCredentials.Credentials.AccessKeyId
    def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
    def sessionToken = roleCredentials.Credentials.SessionToken

    // Export the temporary credentials as environment variables
    withEnv([
        "AWS_ACCESS_KEY_ID=${accessKeyId}",
        "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
        "AWS_SESSION_TOKEN=${sessionToken}"
    ]) {
        sh """#!/bin/bash

        # Jenkins Pipeline Shell Script for Describing AWS Resources

        # VPC
        echo "### Describing VPC ###"
        aws ec2 describe-vpcs \
            --filters "Name=tag:Name,Values=${vpcName}" \
            --query "Vpcs[*].{State:State}"

        # Load Balancer
        echo "### Describing Load Balancer ###"
        aws elbv2 describe-load-balancers \
            --names ${lbName} \
            --query "LoadBalancers[*].{State:State.Code}"

        # EC2 Instances
        echo "### Describing EC2 Instances ###"
        aws ec2 describe-instances \
            --filters "Name=tag:Name,Values=${ec2InstanceName}" \
            --query "Reservations[*].Instances[*].{State:State.Name}"

        # EFS
        echo "### Describing EFS ###"
        aws efs describe-file-systems \
            --query "FileSystems[?Tags[?Key=='Name' && Value=='${efsName}']].{LifeCycleState:LifeCycleState}"

        # EKS Cluster
        echo "### Describing EKS Cluster ###"
        aws eks describe-cluster \
            --name ${eksClusterName} \
            --query "cluster.{Status:status}"

        # RDS Instance
        echo "### Describing RDS Instance ###"
        aws rds describe-db-instances \
            --query "DBInstances[?DBInstanceIdentifier=='${rdsIdentifier}'].{Status:DBInstanceStatus}"

        # KMS - Fetch Key ID and Describe Key
        echo "### Fetching KMS Key ID ###"
        KMS_KEY_ID=\$(aws kms list-aliases \
            --query "Aliases[?AliasName=='${kmsAlias}'].TargetKeyId" \
            --output text)

        if [ -z "\$KMS_KEY_ID" ]; then
            echo "No KMS Key ID found for alias ${kmsAlias}"
            exit 1
        fi

        echo "KMS Key ID: \$KMS_KEY_ID"

        echo "### Describing KMS Key ###"
        aws kms describe-key \
            --key-id \$KMS_KEY_ID \
            --query "KeyMetadata.{Status:KeyState}" \
            --output json

        # ElastiCache Redis
        echo "### Describing Redis Cluster ###"
        aws elasticache describe-cache-clusters \
            --query "CacheClusters[?ReplicationGroupId=='${redisGroupId}'].[CacheClusterStatus]"

        # EKS Node Groups
        echo "### Listing EKS Node Groups ###"
        NODE_GROUPS=\$(aws eks list-nodegroups \
            --cluster-name ${eksClusterName} \
            --query "nodegroups[]" \
            --output text)

        for NODE_GROUP in \$NODE_GROUPS
        do
            echo "Fetching details for node group: \$NODE_GROUP"
            aws eks describe-nodegroup \
                --cluster-name ${eksClusterName} \
                --nodegroup-name \$NODE_GROUP \
                --query "nodegroup.{Status:status,ScalingConfig:scalingConfig}" \
                --output json
            echo ""
        done
        """
    }
}
