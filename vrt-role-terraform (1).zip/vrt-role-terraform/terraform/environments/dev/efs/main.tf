module "efs" {
  source             = "../../../modules/efs"
  cluster-name       = var.cluster-name
  efs-security-group = var.efs-security-group
  backend_bucket     = var.backend_bucket
  region             = var.region
  efs_tags = var.efs_tags
  backend_path       = var.backend_path
  role_arn           = var.role_arn
}
