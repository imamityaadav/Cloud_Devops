def call() {    
    dir('terraform/environments/dev/nodegroups') {
        sh """
            terraform init \
                -backend-config='bucket=${env.BUCKET_NAME}' \
                -backend-config='region=${env.REGION}' \
                -backend-config='key=${env.MAIN_FOLDER}/backend/nodegroups' \
                -backend-config='role_arn=${env.roleArn}' \
                -reconfigure
        """
        def jsonFilePath = "/var/lib/jenkins/workspace/curl-test/terraform/variables/payload.json"
        writeFile file: jsonFilePath, text: params.JSON_PAYLOAD

        println "JSON payload has been saved at: ${jsonFilePath}"
        
        def tfPlanCmd = "terraform plan -out=ng_tfplan --var-file=../../../variables/payload.json"
        sh tfPlanCmd
        sh 'terraform show -no-color ng_tfplan > ng_tfplan.txt'
        def autoApprove = env.AUTO_APPROVE.toBoolean()

        // Check if autoApprove is false, then ask for manual approval
        if (!autoApprove) {
            def plan = readFile 'ng_tfplan.txt'
            input message: "Do you want to apply the plan?",
                  parameters: [text(name: 'Plan', description: 'Please review the plan', defaultValue: plan)]
        }
        
        sh "terraform apply -input=false ng_tfplan > terraform_output.log"

        def clusterName = env.CLUSTER_NAME
        def region = env.REGION
        def roleArn = env.roleArn
        def targetGroupName = env.TARGET_GROUP_NAME
        def nodeGroupName = env.ALB_NGINX_ASG

        // Step 1: Assume the Role and Get Temporary Credentials
        def assumeRoleOutput = sh(
            script: """
                aws sts assume-role \
                    --role-arn ${roleArn} \
                    --role-session-name my-session \
                    --output json \
                    --region ${region}
            """, 
            returnStdout: true
        ).trim()

        echo "Assume Role Output: ${assumeRoleOutput}"

        def roleCredentials = readJSON(text: assumeRoleOutput)
        def accessKeyId = roleCredentials.Credentials.AccessKeyId
        def secretAccessKey = roleCredentials.Credentials.SecretAccessKey
        def sessionToken = roleCredentials.Credentials.SessionToken

        // Step 2: Execute AWS Commands with Temporary Credentials
        withEnv([
            "AWS_ACCESS_KEY_ID=${accessKeyId}",
            "AWS_SECRET_ACCESS_KEY=${secretAccessKey}",
            "AWS_SESSION_TOKEN=${sessionToken}",
            "AWS_REGION=${region}"
        ]) {
            try {
                // Retrieve the Auto Scaling Group name
                def autoScalingGroupName = sh(
                    script: """
                        aws eks describe-nodegroup \
                            --cluster-name ${clusterName} \
                            --nodegroup-name ${clusterName}-${nodeGroupName} \
                            --query "nodegroup.resources.autoScalingGroups[0].name" \
                            --output text
                    """,
                    returnStdout: true
                ).trim()

                echo "Retrieved Auto Scaling Group Name: ${autoScalingGroupName}"

                // Retrieve the Target Group ARN
                def targetGroupArn = sh(
                    script: """
                        aws elbv2 describe-target-groups \
                            --names ${targetGroupName} \
                            --query "TargetGroups[0].TargetGroupArn" \
                            --output text
                    """,
                    returnStdout: true
                ).trim()

                echo "Retrieved Target Group ARN: ${targetGroupArn}"

                // Attach Auto Scaling Group to Target Group
                sh """
                    aws autoscaling attach-load-balancer-target-groups \
                        --auto-scaling-group-name ${autoScalingGroupName} \
                        --target-group-arns ${targetGroupArn}
                """

            } catch (Exception e) {
                echo "Error occurred: ${e.getMessage()}"
            }
        }
    }
}
